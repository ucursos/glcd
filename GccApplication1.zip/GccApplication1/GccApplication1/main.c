/*
 * GccApplication1.c
 *
 * Created: 12/11/2016 10:06:11 PM
 * Author : george
 */ 

#define F_CPU 16000000UL    // AVR clock frequency in Hz, used by util/delay.h

#include <inttypes.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <stdio.h>

#include "glcd/ks0108.h"

float result[3];
char data[50];


void InitADC()
{
	// Select Vref=AVcc
	ADMUX |= (1<<REFS0);
	//set prescaller to 128 and enable ADC
	ADCSRA |= (1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0)|(1<<ADEN);
}




uint16_t ReadADC(uint8_t ADCchannel)
{
	//select ADC channel with safety mask
	ADMUX = (ADMUX & 0xF0) | (ADCchannel & 0x0F);
	//single conversion mode
	ADCSRA |= (1<<ADSC);
	// wait until ADC conversion is complete
	while( ADCSRA & (1<<ADSC) );
	return ADC;
}


int main() {

	InitADC();
	ks0108Init(0);


	while (1){
		
		result[0] = (float)((float)ReadADC(0)*3.3)/1023;
		result[1] = ReadADC(1);
		result[2] = ReadADC(2);
		sprintf(data,"x = %0.2f  y = %0.2f      ",result[1],result[2]);
		ks0108GotoXY(0,0);
		ks0108SelectFont(Callibri10,ks0108ReadFontData,BLACK);
		ks0108Puts(data);
		sprintf(data,"Volts = %0.2f   ",result[0]);
		ks0108GotoXY(0,8);
		ks0108SelectFont(Callibri10,ks0108ReadFontData,BLACK);
		ks0108Puts(data);
		sprintf(data,"Volts = %0.2f   ",result[0]);
		ks0108GotoXY(0,16);
		ks0108SelectFont(Callibri10,ks0108ReadFontData,BLACK);
		ks0108Puts(data);
		sprintf(data,"Volts = %0.2f   ",result[0]);
		ks0108GotoXY(0,24);
		ks0108SelectFont(Callibri10,ks0108ReadFontData,BLACK);
		ks0108Puts(data);
		_delay_ms(250);
	}
}

